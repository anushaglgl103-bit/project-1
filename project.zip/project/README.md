# AURA // Cinematic 3D Groq AI Chatbot

A state-of-the-art cinematic AI Chatbot built with **Python Flask**, **Groq LPU Inference**, and **Three.js**.

---

## Features Matrix

| Feature | Details |
| :--- | :--- |
| **1. Dynamic Animations** | Gyroscopic rotating rings, floating particle nebula, pulsating core state changes, audio equalizer waveforms, smooth card tilt, and glowing status pulses. |
| **2. Microphone Input (Mic)** | Real-time speech recognition using the Web Speech API (`webkitSpeechRecognition`) with an interim transcription HUD bar. |
| **3. Persistent Chat History** | Conversation sessions with rename, delete, search filter, auto-save to `data/sessions.json`, and Markdown export. |
| **4. Rich Text Chat** | Streaming Server-Sent Events (SSE), full Markdown support (tables, lists, quotes), syntax highlighted code blocks with one-click copy. |
| **5. Full Voice Chat (STT + TTS)** | Hands-free continuous voice conversation mode, voice actor selection, pitch/rate sliders, per-message read aloud, and reactive audio visualizer. |
| **6. Interactive 3D Effect** | Procedural 3D holographic neural sphere with wireframe icosahedron, three counter-rotating gyro rings, and mouse parallax depth perspective. |
| **7. Cinematic Sci-Fi Effect** | Neon cybernetic glassmorphic HUD, holographic CRT scanline overlay, vignette depth, and Web Audio API sci-fi procedural sound FX. |

---

## 🚀 Quick Setup & Execution

### 1. Configure the Groq API Key
The Groq API key is stored securely in your local `.env` file:
```env
GROQ_API_KEY=gsk_your_groq_api_key_here
FLASK_SECRET_KEY=cinematic_groq_chatbot_super_secret_key
FLASK_PORT=5000
DEFAULT_MODEL=llama-3.3-70b-versatile
```

> You can also enter or update your Groq API key directly inside the web UI by clicking the **⚙️ Settings** icon in the top right corner.

### 2. Run the Server
```bash
python app.py
```
Open your browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 📁 Architecture

```
project/
├── .env                       # API Key & Server Configurations
├── .env.example               # Template environment configuration
├── app.py                     # Flask backend, Groq SSE streaming, and sessions API
├── requirements.txt           # Python dependencies
├── data/
│   └── sessions.json          # Persistent chat history store
├── static/
│   ├── css/
│   │   └── style.css          # Glassmorphism, neon effects, scanlines, and HUD styling
│   └── js/
│       ├── three_orb.js       # Three.js 3D reactive hologram & particle starfield
│       ├── audio_handler.js   # Mic recognition, speech synthesis (TTS), & Web Audio SFX
│       └── chat.js            # SSE streaming, session manager, and 3D card tilt
└── templates/
    └── index.html             # Futuristic cinematic interface layout
```
