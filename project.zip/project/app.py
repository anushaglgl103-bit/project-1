import os
import json
import uuid
import time
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, Response, jsonify, stream_with_context
from dotenv import load_dotenv

# Load environment variables
load_dotenv(override=True)

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "cinematic_groq_chatbot_super_secret_key")

DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)
SESSIONS_FILE = DATA_DIR / "sessions.json"

AVAILABLE_MODELS = [
    {"id": "llama-3.3-70b-versatile", "name": "Llama 3.3 70B (Versatile - Recommended)", "desc": "High intelligence & coding power"},
    {"id": "llama-3.1-8b-instant", "name": "Llama 3.1 8B (Instant)", "desc": "Blazing fast real-time conversational responses"},
    {"id": "mixtral-8x7b-32768", "name": "Mixtral 8x7B (32k Context)", "desc": "Excellent multi-step reasoning & long context"},
    {"id": "gemma2-9b-it", "name": "Gemma 2 9B", "desc": "Google's high-efficiency lightweight model"}
]

def get_groq_client():
    """Retrieve Groq client if key is configured."""
    key = os.getenv("GROQ_API_KEY", "").strip()
    if not key or key == "your_groq_api_key_here":
        return None, key
    try:
        from groq import Groq
        return Groq(api_key=key), key
    except Exception as e:
        print(f"Error initializing Groq client: {e}")
        return None, key

def load_sessions():
    """Load chat sessions from JSON file."""
    if not SESSIONS_FILE.exists():
        return {}
    try:
        with open(SESSIONS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading sessions: {e}")
        return {}

def save_sessions(sessions):
    """Save chat sessions to JSON file."""
    try:
        with open(SESSIONS_FILE, "w", encoding="utf-8") as f:
            json.dump(sessions, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"Error saving sessions: {e}")

@app.route("/")
def index():
    """Render main cinematic application."""
    return render_template("index.html")

@app.route("/api/health")
def health():
    """Check API and key status."""
    key = os.getenv("GROQ_API_KEY", "").strip()
    is_valid_format = key.startswith("gsk_") if key else False
    is_configured = bool(key and key != "your_groq_api_key_here")
    return jsonify({
        "status": "online",
        "has_key": is_configured,
        "is_valid_format": is_valid_format,
        "default_model": os.getenv("DEFAULT_MODEL", "llama-3.3-70b-versatile"),
        "models": AVAILABLE_MODELS
    })

@app.route("/api/save-key", methods=["POST"])
def save_key():
    """Update GROQ_API_KEY in process and in .env file."""
    data = request.get_json() or {}
    new_key = data.get("api_key", "").strip()
    if not new_key:
        return jsonify({"success": False, "error": "Key cannot be empty"}), 400

    os.environ["GROQ_API_KEY"] = new_key

    # Update .env file
    env_path = Path(__file__).parent / ".env"
    lines = []
    found = False
    if env_path.exists():
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("GROQ_API_KEY="):
                    lines.append(f"GROQ_API_KEY={new_key}\n")
                    found = True
                else:
                    lines.append(line)
    if not found:
        lines.append(f"GROQ_API_KEY={new_key}\n")

    with open(env_path, "w", encoding="utf-8") as f:
        f.writelines(lines)

    return jsonify({"success": True, "message": "Groq API Key updated successfully."})

@app.route("/api/chat/stream", methods=["POST"])
def chat_stream():
    """Stream response from Groq via Server-Sent Events (SSE)."""
    payload = request.get_json() or {}
    messages = payload.get("messages", [])
    model = payload.get("model", os.getenv("DEFAULT_MODEL", "llama-3.3-70b-versatile"))
    system_prompt = payload.get("system_prompt", (
        "You are AURA, an advanced cinematic AI entity with deep analytical intelligence, "
        "crisp futuristic wit, and elegant visual clarity. Format answers with rich Markdown, "
        "proper headings, clean lists, and code blocks with syntax tags when applicable."
    ))

    # Prepend system message if not present
    formatted_messages = []
    if not any(m.get("role") == "system" for m in messages):
        formatted_messages.append({"role": "system", "content": system_prompt})
    
    for m in messages:
        formatted_messages.append({"role": m.get("role", "user"), "content": m.get("content", "")})

    client, key = get_groq_client()

    def generate():
        if not client:
            # Cinematic Mock / Key Reminder response if API key is not yet set
            demo_text = (
                "### ⚡ Cinematic Core Activated: Groq API Key Needed\n\n"
                "Greetings! I am **AURA (Autonomous Universal Reactive Agent)**.\n\n"
                "To unleash lightning-fast neural completions powered by Groq's LPU acceleration:\n\n"
                "1. Click the **⚙️ Settings** icon in the upper right corner or open the `.env` file.\n"
                "2. Paste your free **Groq API Key** (`gsk_...` from [console.groq.com/keys](https://console.groq.com/keys)).\n"
                "3. Once saved, all responses will stream with sub-second latency!\n\n"
                "> *3D visualizer, voice mic dictation, and speech synthesis audio are ready for action.*"
            )
            for word in demo_text.split(" "):
                yield f"data: {json.dumps({'delta': word + ' '})}\n\n"
                time.sleep(0.04)
            yield f"data: {json.dumps({'done': True, 'model': model, 'status': 'no_key'})}\n\n"
            return

        try:
            stream = client.chat.completions.create(
                model=model,
                messages=formatted_messages,
                temperature=payload.get("temperature", 0.7),
                max_tokens=payload.get("max_tokens", 2048),
                stream=True
            )
            for chunk in stream:
                content = chunk.choices[0].delta.content if chunk.choices and chunk.choices[0].delta else None
                if content:
                    yield f"data: {json.dumps({'delta': content})}\n\n"
            yield f"data: {json.dumps({'done': True, 'model': model})}\n\n"
        except Exception as e:
            err_msg = str(e)
            yield f"data: {json.dumps({'error': err_msg})}\n\n"
            yield f"data: {json.dumps({'done': True, 'error': True})}\n\n"

    return Response(stream_with_context(generate()), mimetype="text/event-stream")

# --- Session Management Endpoints ---

@app.route("/api/sessions", methods=["GET"])
def list_sessions():
    """List all saved sessions ordered by timestamp."""
    sessions = load_sessions()
    session_list = []
    for sid, sdata in sessions.items():
        session_list.append({
            "id": sid,
            "title": sdata.get("title", "New Conversation"),
            "created_at": sdata.get("created_at", ""),
            "updated_at": sdata.get("updated_at", ""),
            "message_count": len(sdata.get("messages", []))
        })
    session_list.sort(key=lambda x: x["updated_at"], reverse=True)
    return jsonify({"sessions": session_list})

@app.route("/api/sessions", methods=["POST"])
def create_session():
    """Create a new chat session."""
    data = request.get_json() or {}
    session_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    new_session = {
        "id": session_id,
        "title": data.get("title", "New Conversation"),
        "created_at": now,
        "updated_at": now,
        "messages": data.get("messages", [])
    }
    
    sessions = load_sessions()
    sessions[session_id] = new_session
    save_sessions(sessions)
    return jsonify(new_session)

@app.route("/api/sessions/<session_id>", methods=["GET"])
def get_session(session_id):
    """Get complete history for a session."""
    sessions = load_sessions()
    if session_id not in sessions:
        return jsonify({"error": "Session not found"}), 404
    return jsonify(sessions[session_id])

@app.route("/api/sessions/<session_id>", methods=["PATCH"])
def update_session(session_id):
    """Update title or metadata of a session."""
    data = request.get_json() or {}
    sessions = load_sessions()
    if session_id not in sessions:
        return jsonify({"error": "Session not found"}), 404
    
    if "title" in data:
        sessions[session_id]["title"] = data["title"]
    sessions[session_id]["updated_at"] = datetime.utcnow().isoformat()
    save_sessions(sessions)
    return jsonify(sessions[session_id])

@app.route("/api/sessions/<session_id>", methods=["DELETE"])
def delete_session(session_id):
    """Delete a session."""
    sessions = load_sessions()
    if session_id in sessions:
        del sessions[session_id]
        save_sessions(sessions)
    return jsonify({"success": True})

@app.route("/api/sessions/<session_id>/save", methods=["POST"])
def save_session_messages(session_id):
    """Save updated messages for a session."""
    data = request.get_json() or {}
    messages = data.get("messages", [])
    title = data.get("title")

    sessions = load_sessions()
    now = datetime.utcnow().isoformat()

    if session_id not in sessions:
        sessions[session_id] = {
            "id": session_id,
            "title": title or (messages[0]["content"][:30] if messages else "New Conversation"),
            "created_at": now,
            "updated_at": now,
            "messages": messages
        }
    else:
        sessions[session_id]["messages"] = messages
        sessions[session_id]["updated_at"] = now
        if title:
            sessions[session_id]["title"] = title

    save_sessions(sessions)
    return jsonify({"success": True, "session": sessions[session_id]})

if __name__ == "__main__":
    port = int(os.getenv("FLASK_PORT", 5000))
    print(f"[*] Launching Cinematic Groq Chatbot on http://127.0.0.1:{port}")
    app.run(host="127.0.0.1", port=port, debug=False)
