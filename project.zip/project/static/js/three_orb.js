/**
 * AURA // 3D HOLOGRAPHIC AI CORE
 * Three.js Procedural Reactive Neural Sphere & Particle Field
 */

class NeuralOrbVisualizer {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;

    this.state = 'idle'; // 'idle', 'listening', 'thinking', 'speaking'
    this.audioLevel = 0.0;
    this.targetAudioLevel = 0.0;
    this.mouse = { x: 0, y: 0, targetX: 0, targetY: 0 };
    this.clock = new THREE.Clock();
    this.enabled = true;

    this.init();
    this.animate();
    this.bindEvents();
  }

  init() {
    // 1. Scene & Camera
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x06080e, 0.0018);

    const aspect = window.innerWidth / window.innerHeight;
    this.camera = new THREE.PerspectiveCamera(50, aspect, 0.1, 1000);
    this.camera.position.z = 85;
    this.camera.position.y = 12;

    // 2. WebGL Renderer
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      alpha: true,
      antialias: true
    });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // 3. Core Hologram Group
    this.coreGroup = new THREE.Group();
    this.scene.add(this.coreGroup);

    // Inner Icosahedron (Neural Nucleus)
    const innerGeom = new THREE.IcosahedronGeometry(14, 2);
    this.innerMat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      wireframe: true,
      transparent: true,
      opacity: 0.55
    });
    this.innerCore = new THREE.Mesh(innerGeom, this.innerMat);
    this.coreGroup.add(this.innerCore);

    // Solid Inner Glow Sphere
    const glowGeom = new THREE.SphereGeometry(10, 32, 32);
    this.glowMat = new THREE.MeshBasicMaterial({
      color: 0x0088ff,
      transparent: true,
      opacity: 0.25
    });
    this.glowSphere = new THREE.Mesh(glowGeom, this.glowMat);
    this.coreGroup.add(this.glowSphere);

    // Outer Gyro Ring 1 (Equatorial)
    const ring1Geom = new THREE.TorusGeometry(20, 0.25, 16, 100);
    this.ring1Mat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      transparent: true,
      opacity: 0.7
    });
    this.ring1 = new THREE.Mesh(ring1Geom, this.ring1Mat);
    this.coreGroup.add(this.ring1);

    // Outer Gyro Ring 2 (Polar)
    const ring2Geom = new THREE.TorusGeometry(23, 0.2, 16, 100);
    this.ring2Mat = new THREE.MeshBasicMaterial({
      color: 0x8b5cf6,
      transparent: true,
      opacity: 0.6
    });
    this.ring2 = new THREE.Mesh(ring2Geom, this.ring2Mat);
    this.ring2.rotation.x = Math.PI / 2;
    this.coreGroup.add(this.ring2);

    // Outer Gyro Ring 3 (Diagonal)
    const ring3Geom = new THREE.TorusGeometry(26, 0.18, 16, 100);
    this.ring3Mat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.5
    });
    this.ring3 = new THREE.Mesh(ring3Geom, this.ring3Mat);
    this.ring3.rotation.x = Math.PI / 4;
    this.ring3.rotation.y = Math.PI / 4;
    this.coreGroup.add(this.ring3);

    // 4. Background Starfield / Particle Nebula
    const particleCount = 1400;
    const particleGeom = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    const cCyan = new THREE.Color(0x00f0ff);
    const cViolet = new THREE.Color(0x8b5cf6);
    const cWhite = new THREE.Color(0xffffff);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 320;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 220;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 260;

      const mixVal = Math.random();
      const pColor = mixVal < 0.4 ? cCyan : (mixVal < 0.8 ? cViolet : cWhite);
      colors[i * 3] = pColor.r;
      colors[i * 3 + 1] = pColor.g;
      colors[i * 3 + 2] = pColor.b;
    }

    particleGeom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeom.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 1.4,
      vertexColors: true,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending
    });

    this.particles = new THREE.Points(particleGeom, particleMat);
    this.scene.add(this.particles);
  }

  bindEvents() {
    window.addEventListener('resize', () => {
      if (!this.canvas) return;
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });

    window.addEventListener('mousemove', (e) => {
      this.mouse.targetX = (e.clientX / window.innerWidth - 0.5) * 2;
      this.mouse.targetY = -(e.clientY / window.innerHeight - 0.5) * 2;
    });
  }

  setState(newState) {
    this.state = newState;
    const tag = document.getElementById('orbStateTag');
    const statusText = document.getElementById('statusText');
    const statusDot = document.getElementById('statusDot');

    if (this.state === 'idle') {
      if (tag) tag.textContent = 'IDLE STATE // READY';
      if (statusText) statusText.textContent = 'ONLINE // READY';
      if (statusDot) statusDot.className = 'status-indicator online';
      this.innerMat.color.setHex(0x00f0ff);
      this.glowMat.color.setHex(0x0088ff);
    } else if (this.state === 'listening') {
      if (tag) tag.textContent = 'LISTENING // AUDIO DETECTED';
      if (statusText) statusText.textContent = 'TRANSCRIBING AUDIO';
      if (statusDot) statusDot.className = 'status-indicator busy';
      this.innerMat.color.setHex(0xef4444);
      this.glowMat.color.setHex(0xff3366);
    } else if (this.state === 'thinking') {
      if (tag) tag.textContent = 'PROCESSING // LPU STREAM';
      if (statusText) statusText.textContent = 'GROQ LPU GENERATING';
      if (statusDot) statusDot.className = 'status-indicator busy';
      this.innerMat.color.setHex(0x8b5cf6);
      this.glowMat.color.setHex(0xa855f7);
    } else if (this.state === 'speaking') {
      if (tag) tag.textContent = 'VOCAL FEEDBACK // ACTIVE';
      if (statusText) statusText.textContent = 'VOICE PLAYBACK';
      if (statusDot) statusDot.className = 'status-indicator busy';
      this.innerMat.color.setHex(0x00f0ff);
      this.glowMat.color.setHex(0x00f0ff);
    }
  }

  setAudioLevel(level) {
    this.targetAudioLevel = level;
  }

  toggle(show) {
    this.enabled = show;
    this.canvas.style.display = show ? 'block' : 'none';
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    if (!this.enabled) return;

    const delta = this.clock.getDelta();
    const elapsedTime = this.clock.getElapsedTime();

    // Smooth audio reactivity lerp
    this.audioLevel += (this.targetAudioLevel - this.audioLevel) * 0.2;

    // Smooth mouse parallax
    this.mouse.x += (this.mouse.targetX - this.mouse.x) * 0.05;
    this.mouse.y += (this.mouse.targetY - this.mouse.y) * 0.05;

    // Base Rotation Speeds depending on state
    let rotSpeed = 0.4;
    let pulseScale = 1.0;

    if (this.state === 'idle') {
      rotSpeed = 0.3;
      pulseScale = 1.0 + Math.sin(elapsedTime * 1.5) * 0.04;
    } else if (this.state === 'listening') {
      rotSpeed = 0.7;
      pulseScale = 1.05 + this.audioLevel * 0.3 + Math.sin(elapsedTime * 6) * 0.05;
    } else if (this.state === 'thinking') {
      rotSpeed = 1.8;
      pulseScale = 1.1 + Math.sin(elapsedTime * 8) * 0.08;
    } else if (this.state === 'speaking') {
      rotSpeed = 0.8;
      pulseScale = 1.05 + this.audioLevel * 0.45 + Math.sin(elapsedTime * 4) * 0.05;
    }

    // Core Rotation
    this.innerCore.rotation.x += delta * rotSpeed * 0.6;
    this.innerCore.rotation.y += delta * rotSpeed;
    this.innerCore.scale.set(pulseScale, pulseScale, pulseScale);

    this.glowSphere.scale.set(pulseScale * 0.95, pulseScale * 0.95, pulseScale * 0.95);

    // Gyro Rings counter-rotation
    this.ring1.rotation.z += delta * (rotSpeed * 0.8);
    this.ring2.rotation.x += delta * (rotSpeed * 0.6);
    this.ring3.rotation.y += delta * (rotSpeed * 0.7);

    const ringExpansion = (pulseScale - 1) * 0.5;
    this.ring1.scale.set(1 + ringExpansion, 1 + ringExpansion, 1 + ringExpansion);
    this.ring2.scale.set(1 + ringExpansion * 1.2, 1 + ringExpansion * 1.2, 1 + ringExpansion * 1.2);
    this.ring3.scale.set(1 + ringExpansion * 1.4, 1 + ringExpansion * 1.4, 1 + ringExpansion * 1.4);

    // Subtle Core position tilt based on mouse
    this.coreGroup.position.x = this.mouse.x * 6;
    this.coreGroup.position.y = 12 + this.mouse.y * 4;
    this.coreGroup.rotation.y = this.mouse.x * 0.3;
    this.coreGroup.rotation.x = -this.mouse.y * 0.3;

    // Slow drifting particle nebula
    if (this.particles) {
      this.particles.rotation.y = elapsedTime * 0.03;
      this.particles.rotation.x = elapsedTime * 0.015;
    }

    this.renderer.render(this.scene, this.camera);
  }
}

// Global instance handle
window.neuralOrb = null;
window.addEventListener('DOMContentLoaded', () => {
  window.neuralOrb = new NeuralOrbVisualizer('threeCanvas');
});
