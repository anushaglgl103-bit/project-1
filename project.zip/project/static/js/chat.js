/**
 * AURA // CHAT CONTROLLER & STATE MANAGER
 * Real-time SSE Streaming, Chat History, 3D Card Tilt, & Groq Integration
 */

class ChatApp {
  constructor() {
    this.currentSessionId = null;
    this.messages = [];
    this.sessions = [];
    this.activeModel = 'llama-3.3-70b-versatile';
    this.isStreaming = false;
    this.abortController = null;
    this.cardTiltEnabled = true;

    this.cacheDom();
    this.bindEvents();
    this.initMarkdown();
    this.checkHealthAndConfig();
    this.loadSessions();
  }

  cacheDom() {
    // Top Nav
    this.toggleSidebarBtn = document.getElementById('toggleSidebarBtn');
    this.sidebar = document.getElementById('sidebar');
    this.voiceModeToggle = document.getElementById('voiceModeToggle');
    this.soundFxToggle = document.getElementById('soundFxToggle');
    this.openSettingsBtn = document.getElementById('openSettingsBtn');
    this.statusDot = document.getElementById('statusDot');
    this.statusText = document.getElementById('statusText');
    this.hudModelName = document.getElementById('hudModelName');
    this.hudLatency = document.getElementById('hudLatency');

    // Sidebar
    this.newChatBtn = document.getElementById('newChatBtn');
    this.searchSessionInput = document.getElementById('searchSessionInput');
    this.sessionsList = document.getElementById('sessionsList');
    this.exportChatBtn = document.getElementById('exportChatBtn');
    this.clearAllHistoryBtn = document.getElementById('clearAllHistoryBtn');

    // Chat Area
    this.chatContainer = document.getElementById('chatContainer');
    this.welcomeHero = document.getElementById('welcomeHero');
    this.messagesList = document.getElementById('messagesList');
    this.promptChips = document.querySelectorAll('.prompt-chip');

    // Input Dock
    this.chatForm = document.getElementById('chatForm');
    this.messageInput = document.getElementById('messageInput');
    this.micBtn = document.getElementById('micBtn');
    this.sendBtn = document.getElementById('sendBtn');
    this.stopGenerationBtn = document.getElementById('stopGenerationBtn');
    this.cancelVoiceBtn = document.getElementById('cancelVoiceBtn');

    // Settings Modal
    this.settingsModal = document.getElementById('settingsModal');
    this.closeSettingsBtn = document.getElementById('closeSettingsBtn');
    this.saveAndCloseModalBtn = document.getElementById('saveAndCloseModalBtn');
    this.apiKeyInput = document.getElementById('apiKeyInput');
    this.keyBadge = document.getElementById('keyBadge');
    this.saveApiKeyBtn = document.getElementById('saveApiKeyBtn');
    this.toggleKeyVisibilityBtn = document.getElementById('toggleKeyVisibilityBtn');
    this.modelSelect = document.getElementById('modelSelect');

    // Voice & Effects Controls
    this.ttsVoiceSelect = document.getElementById('ttsVoiceSelect');
    this.ttsRateSlider = document.getElementById('ttsRateSlider');
    this.ttsPitchSlider = document.getElementById('ttsPitchSlider');
    this.rateVal = document.getElementById('rateVal');
    this.pitchVal = document.getElementById('pitchVal');

    this.toggleScanlines = document.getElementById('toggleScanlines');
    this.toggle3DCore = document.getElementById('toggle3DCore');
    this.toggleCardTilt = document.getElementById('toggleCardTilt');
    this.toggleSoundEffects = document.getElementById('toggleSoundEffects');
    this.scanlinesOverlay = document.getElementById('scanlinesOverlay');
  }

  initMarkdown() {
    if (typeof marked !== 'undefined') {
      marked.setOptions({
        gfm: true,
        breaks: true,
        highlight: (code, lang) => {
          if (typeof hljs !== 'undefined' && lang && hljs.getLanguage(lang)) {
            try {
              return hljs.highlight(code, { language: lang }).value;
            } catch (__) {}
          }
          if (typeof hljs !== 'undefined') {
            try {
              return hljs.highlightAuto(code).value;
            } catch (__) {}
          }
          return code;
        }
      });
    }
  }

  bindEvents() {
    // Form Submit
    this.chatForm.addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleSendMessage();
    });

    // Auto-grow textarea & Enter to Send
    this.messageInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.handleSendMessage();
      }
    });

    this.messageInput.addEventListener('input', () => {
      this.messageInput.style.height = 'auto';
      this.messageInput.style.height = Math.min(this.messageInput.scrollHeight, 160) + 'px';
    });

    // Sidebar Toggles
    this.toggleSidebarBtn.addEventListener('click', () => {
      this.sidebar.classList.toggle('collapsed');
      this.sidebar.classList.toggle('open');
      window.audioHandler?.playSfx('click');
    });

    this.newChatBtn.addEventListener('click', () => {
      this.createNewChatSession();
      window.audioHandler?.playSfx('click');
    });

    this.searchSessionInput.addEventListener('input', (e) => {
      this.filterSessions(e.target.value);
    });

    this.exportChatBtn.addEventListener('click', () => {
      this.exportCurrentChat();
    });

    this.clearAllHistoryBtn.addEventListener('click', () => {
      this.clearAllHistory();
    });

    // Prompt Chips
    this.promptChips.forEach(chip => {
      chip.addEventListener('click', () => {
        const prompt = chip.getAttribute('data-prompt');
        if (prompt) {
          this.messageInput.value = prompt;
          this.handleSendMessage();
        }
      });
    });

    // Mic & Voice Controls
    this.micBtn.addEventListener('click', () => {
      window.audioHandler?.toggleListening();
    });

    if (this.cancelVoiceBtn) {
      this.cancelVoiceBtn.addEventListener('click', () => {
        window.audioHandler?.stopListening();
      });
    }

    this.voiceModeToggle.addEventListener('click', () => {
      this.voiceModeToggle.classList.toggle('active');
      const isActive = this.voiceModeToggle.classList.contains('active');
      if (window.audioHandler) {
        window.audioHandler.voiceModeEnabled = isActive;
      }
      this.showToast(isActive ? 'Voice Chat Mode: ON' : 'Voice Chat Mode: OFF', 'success');
      window.audioHandler?.playSfx('click');
    });

    this.soundFxToggle.addEventListener('click', () => {
      if (!window.audioHandler) return;
      window.audioHandler.soundEffectsEnabled = !window.audioHandler.soundEffectsEnabled;
      const isEnabled = window.audioHandler.soundEffectsEnabled;
      this.soundFxToggle.innerHTML = isEnabled 
        ? '<i class="fa-solid fa-bell"></i>' 
        : '<i class="fa-solid fa-bell-slash"></i>';
      this.showToast(isEnabled ? 'Sound Effects Enabled' : 'Sound Effects Muted');
    });

    // Stop Generation Button
    this.stopGenerationBtn.addEventListener('click', () => {
      if (this.abortController) {
        this.abortController.abort();
        this.stopStreamingState();
        this.showToast('Generation halted');
      }
    });

    // Settings Modal
    this.openSettingsBtn.addEventListener('click', () => {
      this.openSettings();
      window.audioHandler?.playSfx('click');
    });
    this.closeSettingsBtn.addEventListener('click', () => {
      this.closeSettings();
    });
    this.saveAndCloseModalBtn.addEventListener('click', () => {
      this.closeSettings();
    });

    this.saveApiKeyBtn.addEventListener('click', () => {
      this.saveApiKey();
    });

    this.toggleKeyVisibilityBtn.addEventListener('click', () => {
      const isPass = this.apiKeyInput.type === 'password';
      this.apiKeyInput.type = isPass ? 'text' : 'password';
      this.toggleKeyVisibilityBtn.innerHTML = isPass ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>';
    });

    this.modelSelect.addEventListener('change', (e) => {
      this.activeModel = e.target.value;
      if (this.hudModelName) {
        this.hudModelName.textContent = this.activeModel.toUpperCase();
      }
      this.showToast(`Model updated to ${this.activeModel}`);
    });

    // Voice sliders
    this.ttsRateSlider.addEventListener('input', (e) => {
      const val = parseFloat(e.target.value);
      this.rateVal.textContent = val.toFixed(1) + 'x';
      if (window.audioHandler) window.audioHandler.ttsRate = val;
    });

    this.ttsPitchSlider.addEventListener('input', (e) => {
      const val = parseFloat(e.target.value);
      this.pitchVal.textContent = val.toFixed(2);
      if (window.audioHandler) window.audioHandler.ttsPitch = val;
    });

    this.ttsVoiceSelect.addEventListener('change', (e) => {
      if (window.audioHandler) window.audioHandler.setVoice(parseInt(e.target.value));
    });

    // Cinematic Visual toggles
    this.toggleScanlines.addEventListener('change', (e) => {
      if (this.scanlinesOverlay) {
        this.scanlinesOverlay.style.display = e.target.checked ? 'block' : 'none';
      }
    });

    this.toggle3DCore.addEventListener('change', (e) => {
      if (window.neuralOrb) {
        window.neuralOrb.toggle(e.target.checked);
      }
    });

    this.toggleCardTilt.addEventListener('change', (e) => {
      this.cardTiltEnabled = e.target.checked;
    });

    this.toggleSoundEffects.addEventListener('change', (e) => {
      if (window.audioHandler) {
        window.audioHandler.soundEffectsEnabled = e.target.checked;
      }
    });
  }

  /* -------------------------------------------------------------
     BACKEND HEALTH & CONFIG
     ------------------------------------------------------------- */
  async checkHealthAndConfig() {
    try {
      const res = await fetch('/api/health');
      const data = await res.json();
      if (data.has_key) {
        this.keyBadge.className = 'label-badge active';
        this.keyBadge.textContent = 'CONNECTED';
        this.statusDot.className = 'status-indicator online';
        this.statusText.textContent = 'GROQ LPU ONLINE';
      } else {
        this.keyBadge.className = 'label-badge missing';
        this.keyBadge.textContent = 'KEY REQUIRED';
        this.statusDot.className = 'status-indicator warning';
        this.statusText.textContent = 'KEY PENDING (.env)';
      }

      if (data.default_model) {
        this.activeModel = data.default_model;
        this.modelSelect.value = data.default_model;
        if (this.hudModelName) {
          this.hudModelName.textContent = data.default_model.toUpperCase();
        }
      }
    } catch (e) {
      console.warn('Error checking backend health:', e);
    }
  }

  async saveApiKey() {
    const key = this.apiKeyInput.value.trim();
    if (!key) {
      this.showToast('Please enter a valid key', 'error');
      return;
    }
    try {
      const res = await fetch('/api/save-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ api_key: key })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast('Groq API Key saved successfully!', 'success');
        this.keyBadge.className = 'label-badge active';
        this.keyBadge.textContent = 'CONNECTED';
        this.statusDot.className = 'status-indicator online';
        this.statusText.textContent = 'GROQ LPU ONLINE';
      } else {
        this.showToast(data.error || 'Failed to save key', 'error');
      }
    } catch (e) {
      this.showToast('Error connecting to backend', 'error');
    }
  }

  openSettings() {
    this.settingsModal.style.display = 'flex';
  }

  closeSettings() {
    this.settingsModal.style.display = 'none';
  }

  /* -------------------------------------------------------------
     SESSIONS & CHAT HISTORY
     ------------------------------------------------------------- */
  async loadSessions() {
    try {
      const res = await fetch('/api/sessions');
      const data = await res.json();
      this.sessions = data.sessions || [];
      this.renderSessionsList();

      // Open latest session or start fresh
      if (this.sessions.length > 0) {
        this.selectSession(this.sessions[0].id);
      } else {
        this.createNewChatSession();
      }
    } catch (e) {
      console.warn('Error loading sessions:', e);
      this.createNewChatSession();
    }
  }

  renderSessionsList(filtered = null) {
    const list = filtered || this.sessions;
    this.sessionsList.innerHTML = '';

    if (list.length === 0) {
      this.sessionsList.innerHTML = `
        <div style="padding: 16px; text-align: center; color: var(--text-muted); font-size: 0.8rem;">
          No conversations found.
        </div>
      `;
      return;
    }

    list.forEach(sess => {
      const item = document.createElement('div');
      item.className = `session-item ${sess.id === this.currentSessionId ? 'active' : ''}`;
      item.setAttribute('data-id', sess.id);

      item.innerHTML = `
        <div class="session-item-content">
          <i class="fa-regular fa-message session-icon"></i>
          <span class="session-title" title="${this.escapeHtml(sess.title)}">${this.escapeHtml(sess.title)}</span>
        </div>
        <div class="session-item-actions">
          <button class="btn-item-action edit" title="Rename Session">
            <i class="fa-solid fa-pen"></i>
          </button>
          <button class="btn-item-action delete" title="Delete Session">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </div>
      `;

      item.addEventListener('click', (e) => {
        if (e.target.closest('.btn-item-action')) return;
        this.selectSession(sess.id);
      });

      const editBtn = item.querySelector('.btn-item-action.edit');
      editBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.renameSession(sess.id, sess.title);
      });

      const deleteBtn = item.querySelector('.btn-item-action.delete');
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.deleteSession(sess.id);
      });

      this.sessionsList.appendChild(item);
    });
  }

  filterSessions(query) {
    const q = query.toLowerCase().trim();
    if (!q) {
      this.renderSessionsList();
      return;
    }
    const filtered = this.sessions.filter(s => s.title.toLowerCase().includes(q));
    this.renderSessionsList(filtered);
  }

  async selectSession(sessionId) {
    if (this.currentSessionId === sessionId) return;
    this.currentSessionId = sessionId;

    // Update active class
    document.querySelectorAll('.session-item').forEach(el => {
      el.classList.toggle('active', el.getAttribute('data-id') === sessionId);
    });

    try {
      const res = await fetch(`/api/sessions/${sessionId}`);
      const data = await res.json();
      this.messages = data.messages || [];
      this.renderMessages();
    } catch (e) {
      console.warn('Error fetching session messages:', e);
    }
  }

  async createNewChatSession() {
    try {
      const res = await fetch('/api/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: 'New Conversation', messages: [] })
      });
      const newSession = await res.json();
      this.currentSessionId = newSession.id;
      this.messages = [];
      this.sessions.unshift({
        id: newSession.id,
        title: newSession.title,
        updated_at: newSession.updated_at,
        message_count: 0
      });
      this.renderSessionsList();
      this.renderMessages();
      this.messageInput.focus();
    } catch (e) {
      console.warn('Error creating session:', e);
    }
  }

  async renameSession(sessionId, currentTitle) {
    const newTitle = prompt('Enter conversation name:', currentTitle);
    if (!newTitle || newTitle.trim() === currentTitle) return;

    try {
      await fetch(`/api/sessions/${sessionId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: newTitle.trim() })
      });
      const sess = this.sessions.find(s => s.id === sessionId);
      if (sess) sess.title = newTitle.trim();
      this.renderSessionsList();
      this.showToast('Conversation renamed', 'success');
    } catch (e) {
      this.showToast('Failed to rename conversation', 'error');
    }
  }

  async deleteSession(sessionId) {
    if (!confirm('Are you sure you want to delete this conversation?')) return;
    try {
      await fetch(`/api/sessions/${sessionId}`, { method: 'DELETE' });
      this.sessions = this.sessions.filter(s => s.id !== sessionId);
      this.renderSessionsList();
      this.showToast('Conversation deleted');

      if (this.currentSessionId === sessionId) {
        if (this.sessions.length > 0) {
          this.selectSession(this.sessions[0].id);
        } else {
          this.createNewChatSession();
        }
      }
    } catch (e) {
      this.showToast('Failed to delete session', 'error');
    }
  }

  async clearAllHistory() {
    if (!confirm('Clear all conversation history? This cannot be undone.')) return;
    for (const s of this.sessions) {
      try { await fetch(`/api/sessions/${s.id}`, { method: 'DELETE' }); } catch (e) {}
    }
    this.sessions = [];
    this.createNewChatSession();
    this.showToast('History cleared');
  }

  exportCurrentChat() {
    if (this.messages.length === 0) {
      this.showToast('No messages to export', 'error');
      return;
    }
    let md = `# AURA Chat Export\nSession: ${this.currentSessionId}\nDate: ${new Date().toLocaleString()}\n\n---\n\n`;
    this.messages.forEach(m => {
      md += `### ${m.role === 'user' ? 'USER' : 'AURA'}\n${m.content}\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AURA_Chat_${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
    this.showToast('Exported as Markdown', 'success');
  }

  /* -------------------------------------------------------------
     MESSAGING & SSE STREAMING
     ------------------------------------------------------------- */
  async handleSendMessage() {
    const text = this.messageInput.value.trim();
    if (!text || this.isStreaming) return;

    // Reset input
    this.messageInput.value = '';
    this.messageInput.style.height = 'auto';

    // Play SFX
    window.audioHandler?.playSfx('send');

    // Add user message
    const userMsg = {
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    this.messages.push(userMsg);
    this.appendMessage(userMsg);

    // Auto-update session title if first message
    if (this.messages.length === 1 && this.currentSessionId) {
      const newTitle = text.slice(0, 32) + (text.length > 32 ? '...' : '');
      const sess = this.sessions.find(s => s.id === this.currentSessionId);
      if (sess) {
        sess.title = newTitle;
        this.renderSessionsList();
      }
      fetch(`/api/sessions/${this.currentSessionId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: newTitle })
      }).catch(() => {});
    }

    // Set 3D Orb to Thinking State
    if (window.neuralOrb) window.neuralOrb.setState('thinking');

    // Start Streaming Assistant Message
    await this.startStreamResponse();
  }

  async startStreamResponse() {
    this.isStreaming = true;
    this.startStreamingState();

    const startTime = performance.now();

    // Create placeholder for bot message
    const botMsg = {
      role: 'assistant',
      content: '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    this.messages.push(botMsg);
    const { bubbleBody, rowEl, actionPlayBtn } = this.appendMessage(botMsg, true);

    this.abortController = new AbortController();

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: this.abortController.signal,
        body: JSON.stringify({
          messages: this.messages.map(m => ({ role: m.role, content: m.content })),
          model: this.activeModel
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buffer = '';
      let isFirstChunk = true;

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || !trimmed.startsWith('data: ')) continue;

          const jsonStr = trimmed.slice(6);
          try {
            const data = JSON.parse(jsonStr);

            if (isFirstChunk && data.delta) {
              isFirstChunk = false;
              const ttft = ((performance.now() - startTime) / 1000).toFixed(2);
              if (this.hudLatency) this.hudLatency.textContent = `~${ttft}s TTFT`;
              bubbleBody.innerHTML = ''; // clear typing dots
            }

            if (data.delta) {
              botMsg.content += data.delta;
              bubbleBody.innerHTML = marked.parse(botMsg.content);
              this.applyCodeDecorators(bubbleBody);
              this.scrollToBottom();
            }

            if (data.error) {
              botMsg.content += `\n\n> ⚠️ *Error: ${data.error}*`;
              bubbleBody.innerHTML = marked.parse(botMsg.content);
            }

            if (data.done) {
              break;
            }
          } catch (err) {
            console.warn('JSON parse error on SSE stream:', err, jsonStr);
          }
        }
      }

      // Final render & syntax highlighting
      bubbleBody.innerHTML = marked.parse(botMsg.content || '*No response generated.*');
      this.applyCodeDecorators(bubbleBody);

      // Play receive sound
      window.audioHandler?.playSfx('receive');

      // Save messages to backend
      if (this.currentSessionId) {
        fetch(`/api/sessions/${this.currentSessionId}/save`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: this.messages })
        }).catch(() => {});
      }

      // Voice chat auto-readout if Voice Mode is active
      if (window.audioHandler && window.audioHandler.voiceModeEnabled && botMsg.content) {
        window.audioHandler.speak(botMsg.content, () => {
          if (actionPlayBtn) actionPlayBtn.classList.remove('speaking');
        });
        if (actionPlayBtn) actionPlayBtn.classList.add('speaking');
      } else {
        if (window.neuralOrb) window.neuralOrb.setState('idle');
      }

    } catch (err) {
      if (err.name === 'AbortError') {
        botMsg.content += '\n\n*(Generation stopped by user)*';
      } else {
        botMsg.content += `\n\n> ⚠️ *Connection error: ${err.message}*`;
      }
      bubbleBody.innerHTML = marked.parse(botMsg.content);
      if (window.neuralOrb) window.neuralOrb.setState('idle');
    } finally {
      this.stopStreamingState();
    }
  }

  startStreamingState() {
    this.sendBtn.style.display = 'none';
    this.stopGenerationBtn.style.display = 'flex';
    this.statusDot.className = 'status-indicator busy';
    this.statusText.textContent = 'STREAMING LPU...';
  }

  stopStreamingState() {
    this.isStreaming = false;
    this.abortController = null;
    this.sendBtn.style.display = 'flex';
    this.stopGenerationBtn.style.display = 'none';
    this.statusDot.className = 'status-indicator online';
    this.statusText.textContent = 'ONLINE // READY';
  }

  /* -------------------------------------------------------------
     UI RENDERING & 3D TILT
     ------------------------------------------------------------- */
  renderMessages() {
    this.messagesList.innerHTML = '';
    if (this.messages.length === 0) {
      this.welcomeHero.style.display = 'block';
    } else {
      this.welcomeHero.style.display = 'none';
      this.messages.forEach(m => this.appendMessage(m, false));
    }
    this.scrollToBottom();
  }

  appendMessage(msg, isNewStream = false) {
    this.welcomeHero.style.display = 'none';

    const row = document.createElement('div');
    row.className = `message-row ${msg.role === 'user' ? 'user' : 'bot'}`;

    const avatarIcon = msg.role === 'user' 
      ? '<i class="fa-solid fa-user"></i>' 
      : '<i class="fa-solid fa-atom"></i>';

    const senderName = msg.role === 'user' ? 'COMMANDER' : 'AURA // GROQ';

    row.innerHTML = `
      <div class="message-avatar">${avatarIcon}</div>
      <div class="message-bubble">
        <div class="message-header">
          <span class="message-sender">${senderName}</span>
          <span class="message-time">${msg.timestamp || ''}</span>
        </div>
        <div class="message-body">
          ${isNewStream ? '<div class="typing-indicator"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>' : (marked.parse(msg.content || ''))}
        </div>
        ${msg.role === 'assistant' ? `
          <div class="message-actions">
            <button class="btn-msg-action play-speech" title="Read Aloud (Voice Chat)">
              <i class="fa-solid fa-volume-high"></i> Read
            </button>
            <button class="btn-msg-action copy-text" title="Copy Response">
              <i class="fa-solid fa-copy"></i> Copy
            </button>
          </div>
        ` : ''}
      </div>
    `;

    const bubble = row.querySelector('.message-bubble');
    const bubbleBody = row.querySelector('.message-body');
    const actionPlayBtn = row.querySelector('.btn-msg-action.play-speech');
    const actionCopyBtn = row.querySelector('.btn-msg-action.copy-text');

    // 3D Card Tilt on Hover
    if (this.cardTiltEnabled) {
      this.attach3DTilt(bubble);
    }

    // Bind action buttons
    if (actionPlayBtn) {
      actionPlayBtn.addEventListener('click', () => {
        if (actionPlayBtn.classList.contains('speaking')) {
          window.audioHandler?.stopSpeaking();
          actionPlayBtn.classList.remove('speaking');
        } else {
          document.querySelectorAll('.btn-msg-action.play-speech').forEach(b => b.classList.remove('speaking'));
          actionPlayBtn.classList.add('speaking');
          window.audioHandler?.speak(msg.content, () => {
            actionPlayBtn.classList.remove('speaking');
          });
        }
      });
    }

    if (actionCopyBtn) {
      actionCopyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(msg.content);
        this.showToast('Message copied to clipboard', 'success');
      });
    }

    this.applyCodeDecorators(bubbleBody);
    this.messagesList.appendChild(row);
    this.scrollToBottom();

    return { bubbleBody, rowEl: row, actionPlayBtn };
  }

  attach3DTilt(element) {
    element.addEventListener('mousemove', (e) => {
      if (!this.cardTiltEnabled) return;
      const rect = element.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      const centerX = rect.width / 2;
      const centerY = rect.height / 2;

      const rotateX = ((y - centerY) / centerY) * -5;
      const rotateY = ((x - centerX) / centerX) * 5;

      element.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(6px)`;
    });

    element.addEventListener('mouseleave', () => {
      element.style.transform = 'perspective(800px) rotateX(0deg) rotateY(0deg) translateZ(0px)';
    });
  }

  applyCodeDecorators(container) {
    if (!container) return;
    const preBlocks = container.querySelectorAll('pre');
    preBlocks.forEach(pre => {
      if (pre.querySelector('.code-block-header')) return;

      const codeEl = pre.querySelector('code');
      const lang = codeEl ? (codeEl.className.match(/language-(\w+)/)?.[1] || 'code') : 'code';

      const header = document.createElement('div');
      header.className = 'code-block-header';
      header.innerHTML = `
        <span>${lang.toUpperCase()}</span>
        <button class="btn-copy-code" type="button">
          <i class="fa-solid fa-copy"></i> Copy
        </button>
      `;

      const copyBtn = header.querySelector('.btn-copy-code');
      copyBtn.addEventListener('click', () => {
        const text = codeEl ? codeEl.innerText : pre.innerText;
        navigator.clipboard.writeText(text);
        copyBtn.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';
        setTimeout(() => {
          copyBtn.innerHTML = '<i class="fa-solid fa-copy"></i> Copy';
        }, 2000);
      });

      pre.insertBefore(header, pre.firstChild);
    });
  }

  scrollToBottom() {
    this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  showToast(message, type = 'normal') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icon = type === 'success' 
      ? '<i class="fa-solid fa-check-circle" style="color:#10b981;"></i>' 
      : (type === 'error' ? '<i class="fa-solid fa-circle-exclamation" style="color:#ef4444;"></i>' : '<i class="fa-solid fa-info-circle" style="color:var(--accent-cyan);"></i>');

    toast.innerHTML = `${icon}<span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(20px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }
}

// Global handle
window.showToast = (msg, type) => window.chatApp?.showToast(msg, type);

window.addEventListener('DOMContentLoaded', () => {
  window.chatApp = new ChatApp();
});
