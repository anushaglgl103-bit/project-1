/**
 * AURA // AUDIO HANDLER
 * Web Speech Recognition (Mic), SpeechSynthesis (Voice Chat TTS), & Sci-Fi SFX
 */

class AudioHandler {
  constructor() {
    this.audioCtx = null;
    this.soundEffectsEnabled = true;
    this.voiceModeEnabled = false;
    this.isListening = false;
    this.recognition = null;
    this.currentUtterance = null;
    this.voices = [];
    this.selectedVoice = null;
    this.ttsRate = 1.0;
    this.ttsPitch = 1.0;

    // Visualizer Canvas
    this.visualizerCanvas = document.getElementById('audioVisualizerCanvas');
    this.visualizerCtx = this.visualizerCanvas ? this.visualizerCanvas.getContext('2d') : null;
    this.waveAnimId = null;

    this.initAudioContext();
    this.initSpeechRecognition();
    this.initSpeechSynthesis();
    this.initWaveformVisualizer();
  }

  initAudioContext() {
    try {
      const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    } catch (e) {
      console.warn('Web Audio API not supported:', e);
    }
  }

  ensureAudioContextRunning() {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  /* -------------------------------------------------------------
     SCI-FI SOUND EFFECTS (Procedural Web Audio API)
     ------------------------------------------------------------- */
  playSfx(type) {
    if (!this.soundEffectsEnabled || !this.audioCtx) return;
    this.ensureAudioContextRunning();

    try {
      const ctx = this.audioCtx;
      const now = ctx.currentTime;

      if (type === 'send') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(580, now);
        osc.frequency.exponentialRampToValueAtTime(1180, now + 0.12);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.12);
      } else if (type === 'receive') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(940, now);
        osc.frequency.exponentialRampToValueAtTime(720, now + 0.15);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.15);
      } else if (type === 'click') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(1200, now);
        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.04);
      } else if (type === 'activate') {
        [440, 660, 880].forEach((freq, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + i * 0.05);
          gain.gain.setValueAtTime(0.08, now + i * 0.05);
          gain.gain.exponentialRampToValueAtTime(0.001, now + (i + 1) * 0.09);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + i * 0.05);
          osc.stop(now + (i + 1) * 0.09);
        });
      }
    } catch (e) {
      console.warn('SFX Error:', e);
    }
  }

  /* -------------------------------------------------------------
     SPEECH RECOGNITION (Microphone Voice Input)
     ------------------------------------------------------------- */
  initSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn('Speech Recognition not supported in this browser.');
      return;
    }

    this.recognition = new SpeechRecognition();
    this.recognition.continuous = false;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';

    const micBtn = document.getElementById('micBtn');
    const transcriptionBar = document.getElementById('voiceTranscriptionBar');
    const previewText = document.getElementById('voicePreviewText');
    const messageInput = document.getElementById('messageInput');

    this.recognition.onstart = () => {
      this.isListening = true;
      if (micBtn) micBtn.classList.add('listening');
      if (transcriptionBar) transcriptionBar.style.display = 'flex';
      if (previewText) previewText.textContent = 'Listening to your voice...';
      if (window.neuralOrb) window.neuralOrb.setState('listening');
      this.playSfx('activate');
    };

    this.recognition.onresult = (event) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }

      const activeText = finalTranscript || interimTranscript;
      if (previewText && activeText) {
        previewText.textContent = activeText;
      }
      if (messageInput && activeText) {
        messageInput.value = activeText;
      }

      if (window.neuralOrb) {
        window.neuralOrb.setAudioLevel(0.8);
      }
    };

    this.recognition.onerror = (event) => {
      console.warn('Speech recognition error:', event.error);
      this.stopListening();
      if (event.error !== 'no-speech') {
        window.showToast?.(`Mic note: ${event.error}`, 'error');
      }
    };

    this.recognition.onend = () => {
      this.stopListening();
    };
  }

  toggleListening() {
    if (!this.recognition) {
      window.showToast?.('Speech recognition is not supported in this browser.', 'error');
      return;
    }

    if (this.isListening) {
      this.stopListening();
    } else {
      this.startListening();
    }
  }

  startListening() {
    if (!this.recognition) return;
    try {
      this.recognition.start();
    } catch (e) {
      console.warn('Recognition start exception:', e);
    }
  }

  stopListening() {
    this.isListening = false;
    const micBtn = document.getElementById('micBtn');
    const transcriptionBar = document.getElementById('voiceTranscriptionBar');

    if (micBtn) micBtn.classList.remove('listening');
    if (transcriptionBar) transcriptionBar.style.display = 'none';

    if (this.recognition) {
      try { this.recognition.stop(); } catch (e) {}
    }

    if (window.neuralOrb && window.neuralOrb.state === 'listening') {
      window.neuralOrb.setState('idle');
      window.neuralOrb.setAudioLevel(0);
    }
  }

  /* -------------------------------------------------------------
     SPEECH SYNTHESIS (Voice Chat TTS Readout)
     ------------------------------------------------------------- */
  initSpeechSynthesis() {
    if (!('speechSynthesis' in window)) {
      console.warn('SpeechSynthesis not supported in this browser.');
      return;
    }

    const loadVoices = () => {
      this.voices = window.speechSynthesis.getVoices();
      const voiceSelect = document.getElementById('ttsVoiceSelect');
      if (voiceSelect && this.voices.length > 0) {
        voiceSelect.innerHTML = '';
        this.voices.forEach((v, idx) => {
          const option = document.createElement('option');
          option.value = idx;
          option.textContent = `${v.name} (${v.lang})`;
          if (v.default || v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('David')) {
            option.selected = true;
            this.selectedVoice = v;
          }
          voiceSelect.appendChild(option);
        });

        if (!this.selectedVoice && this.voices.length > 0) {
          this.selectedVoice = this.voices[0];
        }
      }
    };

    loadVoices();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }

  setVoice(index) {
    if (this.voices[index]) {
      this.selectedVoice = this.voices[index];
    }
  }

  stripMarkdownForSpeech(mdText) {
    if (!mdText) return '';
    return mdText
      .replace(/```[\s\S]*?```/g, ' Code snippet omitted. ') // strip full code blocks
      .replace(/`([^`]+)`/g, '$1') // inline code
      .replace(/#+\s/g, '') // headings
      .replace(/\*\*([^*]+)\*\*/g, '$1') // bold
      .replace(/\*([^*]+)\*/g, '$1') // italics
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // links
      .replace(/>\s/g, '') // blockquotes
      .replace(/[-*+]\s/g, '') // bullet lists
      .replace(/\n+/g, ' ') // newlines to spaces
      .trim();
  }

  speak(text, onEndCallback = null) {
    if (!('speechSynthesis' in window)) return;
    this.stopSpeaking();

    const cleanText = this.stripMarkdownForSpeech(text);
    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    if (this.selectedVoice) utterance.voice = this.selectedVoice;
    utterance.rate = this.ttsRate;
    utterance.pitch = this.ttsPitch;

    utterance.onstart = () => {
      if (window.neuralOrb) window.neuralOrb.setState('speaking');
      this.startWaveformAnimation(true);
    };

    utterance.onend = () => {
      this.currentUtterance = null;
      if (window.neuralOrb && window.neuralOrb.state === 'speaking') {
        window.neuralOrb.setState('idle');
      }
      this.startWaveformAnimation(false);
      if (onEndCallback) onEndCallback();
    };

    utterance.onerror = () => {
      this.currentUtterance = null;
      if (window.neuralOrb && window.neuralOrb.state === 'speaking') {
        window.neuralOrb.setState('idle');
      }
      this.startWaveformAnimation(false);
    };

    this.currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  stopSpeaking() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.currentUtterance = null;
    }
    if (window.neuralOrb && window.neuralOrb.state === 'speaking') {
      window.neuralOrb.setState('idle');
    }
    this.startWaveformAnimation(false);
  }

  /* -------------------------------------------------------------
     AUDIO EQUALIZER / WAVEFORM HUD VISUALIZER
     ------------------------------------------------------------- */
  initWaveformVisualizer() {
    if (!this.visualizerCanvas || !this.visualizerCtx) return;
    this.drawEqualizerIdle();
  }

  drawEqualizerIdle() {
    const ctx = this.visualizerCtx;
    const w = this.visualizerCanvas.width;
    const h = this.visualizerCanvas.height;

    ctx.clearRect(0, 0, w, h);
    const bars = 24;
    const barWidth = 4;
    const gap = 3;

    for (let i = 0; i < bars; i++) {
      const x = i * (barWidth + gap) + 6;
      const barHeight = 3;
      const y = (h - barHeight) / 2;

      ctx.fillStyle = 'rgba(0, 240, 255, 0.2)';
      ctx.fillRect(x, y, barWidth, barHeight);
    }
  }

  startWaveformAnimation(active) {
    if (this.waveAnimId) {
      cancelAnimationFrame(this.waveAnimId);
      this.waveAnimId = null;
    }

    if (!active) {
      this.drawEqualizerIdle();
      return;
    }

    const ctx = this.visualizerCtx;
    const w = this.visualizerCanvas.width;
    const h = this.visualizerCanvas.height;
    const bars = 24;
    const barWidth = 4;
    const gap = 3;
    let t = 0;

    const render = () => {
      t += 0.15;
      ctx.clearRect(0, 0, w, h);

      let avgLevel = 0;
      for (let i = 0; i < bars; i++) {
        const x = i * (barWidth + gap) + 6;
        const norm = i / bars;
        const wave = Math.sin(t + norm * Math.PI * 3) * 0.5 + 0.5;
        const randomSpike = Math.random() * 0.4;
        const barHeight = Math.max(3, (wave + randomSpike) * (h - 4));
        const y = (h - barHeight) / 2;

        avgLevel += barHeight / h;

        const grad = ctx.createLinearGradient(0, y, 0, y + barHeight);
        grad.addColorStop(0, '#00f0ff');
        grad.addColorStop(1, '#8b5cf6');
        ctx.fillStyle = grad;
        ctx.fillRect(x, y, barWidth, barHeight);
      }

      avgLevel = avgLevel / bars;
      if (window.neuralOrb) {
        window.neuralOrb.setAudioLevel(avgLevel);
      }

      this.waveAnimId = requestAnimationFrame(render);
    };

    render();
  }
}

// Global audio handler instance
window.audioHandler = null;
window.addEventListener('DOMContentLoaded', () => {
  window.audioHandler = new AudioHandler();
});
